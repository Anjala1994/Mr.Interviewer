# Team Project: Mock Interview Chatbot

## Team - Group 3

## Team Members:
1. Varun Potlacheruvu
2. Tushar Sharma
3. Anjala Thulasiram
4. Renu Dighe

## Project Description

Designed a Chatbot with the help of IBM Watson Assistant
Available to use via the Bluemix.net link on the IBM cloud
Also integrated on Slack and Facebook Messenger.
